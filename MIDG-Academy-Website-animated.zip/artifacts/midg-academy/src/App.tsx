import { type FormEvent, type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowRight,
  Briefcase,
  Building2,
  ClipboardCheck,
  Compass,
  Facebook,
  FileText,
  GraduationCap,
  HeartHandshake,
  Instagram,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Send,
  ShieldCheck,
  Rocket,
  Trophy,
  Users,
  Youtube,
  X,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import ProspectusSection from '@/components/ProspectusSection';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const WHATSAPP_URL = 'https://wa.me/918754064171';
const INSTAGRAM_URL = 'https://www.instagram.com/midg.academy.in/';
const YOUTUBE_URL = 'https://youtube.com/@midg_academy?si=Mruk-hYG8D5Zh7GA';
const FACEBOOK_URL = 'https://www.facebook.com/profile.php?id=61595344136691';
const JUSTDIAL_URL = 'https://www.justdial.com/Chennai/MIDG-ACADEMY-OF-EDUCATION-SERVICES-Parrys/044PXX44-XX44-260926143806-Q9Z6_BZDET';
const GOOGLE_MAPS_URL = 'https://maps.app.goo.gl/pNpyY72trPv2e71M8';

const publicProfileLinks = [
  { label: 'YouTube', detail: '@midg_academy', href: YOUTUBE_URL, icon: Youtube },
  { label: 'Facebook', detail: 'MIDG Academy on Facebook', href: FACEBOOK_URL, icon: Facebook },
  { label: 'Justdial', detail: 'MIDG Academy of Education Services', href: JUSTDIAL_URL, icon: Building2 },
  { label: 'Google Maps', detail: 'View the shared location', href: GOOGLE_MAPS_URL, icon: MapPin },
];

const navItems = [
  ['Home', '#home'],
  ['About Us', '#about'],
  ['Courses & Training', '#training'],
  ['Services', '#services'],
  ['Prospectus', '#prospectus'],
  ['Certificates', '#certificates'],
  ['Accreditations', '#accreditations'],
  ['Partners', '#partnerships'],
  ['Our Founders', '#founders'],
  ['Contact', '#contact'],
];

const universityPartners = [
  { name: 'Asian International University (AIU), Manipur', logo: '/aiu-logo.webp' },
  { name: 'Western State University (WSU)', logo: '/wsu-logo.jpeg' },
  { name: 'Shri Rukmani Dwarkadhish University (SRDU)', logo: '/srdu-logo.png' },
  { name: 'Sikkim Skill University (SSU)', logo: '/ssu-logo.png' },
  { name: 'Swami Vivekananda Subharti University', logo: '/partner-logos/swami-vivekananda-subharti-university.png' },
  { name: 'Rayat Bahra University', logo: '/partner-logos/rayat-bahra-university.png' },
  { name: 'Dhanalakshmi Srinivasan University', logo: '/partner-logos/dhanalakshmi-srinivasan-university.png' },
  { name: 'Manonmaniam Sundaranar University', logo: '/partner-logos/manonmaniam-sundaranar-university.jpg' },
  { name: 'Madurai Kamaraj University', logo: '/partner-logos/madurai-kamaraj-university.jpg' },
  { name: 'Alagappa University', logo: '/partner-logos/alagappa-university.jpg' },
  { name: "Mother Teresa Women's University", logo: '/partner-logos/mother-teresa-womens-university.jpg' },
];

const services = [
  'Educational Support',
  'Academic Tutoring',
  'Professional Training',
  'Skill Development',
  'Corporate Training',
  'Digital Marketing',
  'HR & Recruitment Training',
  'Communication & Soft Skills',
  'Leadership Development',
  'Career Readiness',
  'Faculty Development',
  'Honorary Doctorate Guidance & Consultancy',
  'Educational Guidance & Counselling',
  'University & College Admissions',
  'Online Learning Programmes',
  'Internships & College Projects',
  'Career & Placement Guidance',
  'MS Office & Spoken English',
];

const serviceIcons: Record<string, typeof ArrowRight> = {
  'Educational Support': HeartHandshake,
  'Academic Tutoring': GraduationCap,
  'Professional Training': Briefcase,
  'Skill Development': Rocket,
  'Corporate Training': Users,
  'Digital Marketing': Rocket,
  'HR & Recruitment Training': Users,
  'Communication & Soft Skills': MessageCircle,
  'Leadership Development': Trophy,
  'Career Readiness': Trophy,
  'Faculty Development': Users,
  'Honorary Doctorate Guidance & Consultancy': Compass,
  'Educational Guidance & Counselling': Compass,
  'University & College Admissions': GraduationCap,
  'Online Learning Programmes': GraduationCap,
  'Internships & College Projects': Briefcase,
  'Career & Placement Guidance': Compass,
  'MS Office & Spoken English': MessageCircle,
};

const honoraryDoctorateSupport = [
  'Eligibility guidance',
  'University/institution background verification',
  'Nomination/application process guidance',
  'Documentation assistance',
  'Profile/CV preparation',
  'Communication with institutions',
  'Recognition and accreditation verification',
  'Application-process guidance',
];

const trainingAreas = [
  {
    number: '01',
    title: 'Professional Training',
    copy: 'Practical courses such as digital marketing and HR, alongside training for organisations, colleges and schools.',
    icon: Briefcase,
  },
  {
    number: '02',
    title: 'Skill Development',
    copy: 'Career-readiness support, including interview preparation, recruitment skills and professional development.',
    icon: Rocket,
  },
  {
    number: '03',
    title: 'Academic Tutoring',
    copy: 'Academic support, coaching and admissions guidance for learners planning their next step.',
    icon: GraduationCap,
  },
];

function IconSquare({
  icon: Icon,
  size = 'md',
  className = '',
}: {
  icon: typeof ArrowRight;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}) {
  const dimensions = size === 'sm' ? 'h-8 w-8' : size === 'lg' ? 'h-12 w-12' : 'h-10 w-10';
  const iconDimensions = size === 'sm' ? 'h-4 w-4' : size === 'lg' ? 'h-6 w-6' : 'h-5 w-5';

  return (
    <span
      aria-hidden="true"
      className={`inline-flex shrink-0 items-center justify-center rounded-xl border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--primary))] text-[hsl(var(--secondary))] ${dimensions} ${className}`}
    >
      <Icon className={iconDimensions} strokeWidth={1.8} />
    </span>
  );
}

function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-[hsl(var(--border)/0.65)] bg-[hsl(var(--background)/0.94)] backdrop-blur-xl nav-shadow">
      <div className="mx-auto flex h-[76px] max-w-[1320px] items-center justify-between px-5 sm:px-8 lg:px-12">
        <a href="#home" className="focus-ring flex items-center gap-3" data-testid="link-logo">
          <img src="/midg-academy-logo-round.png" alt="MIDG Academy of Education Services" className="h-14 w-14 object-contain" />
          <span className="hidden border-l border-[hsl(var(--border))] pl-3 text-[10px] font-bold uppercase tracking-[0.22em] text-[hsl(var(--primary))] sm:block">
            Academy of<br />Education Services
          </span>
        </a>
        <nav className="hidden items-center gap-2.5 xl:flex" aria-label="Primary navigation">
          {navItems.map(([label, href]) => (
            <a key={href} href={href} className="focus-ring text-[11px] font-bold uppercase tracking-[0.09em] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--primary))]" data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>
              {label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2 sm:gap-3">
          <SocialLinks location="header" />
          <a href="#contact" className="focus-ring hidden items-center gap-2 rounded-full bg-[hsl(var(--primary))] px-5 py-3 text-xs font-bold uppercase tracking-[0.12em] text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5 sm:flex" data-testid="link-header-enquire">
            Enquire now <IconSquare icon={ArrowRight} size="sm" />
          </a>
          <button type="button" className="focus-ring rounded-xl xl:hidden" aria-label={open ? 'Close navigation' : 'Open navigation'} onClick={() => setOpen((value) => !value)} data-testid="button-mobile-menu">
            <IconSquare icon={open ? X : Menu} />
          </button>
        </div>
      </div>
      {open && (
        <nav className="border-t border-[hsl(var(--border))] bg-[hsl(var(--background))] px-5 py-5 xl:hidden" aria-label="Mobile navigation">
          <div className="mx-auto grid max-w-[1320px] gap-1">
            {navItems.map(([label, href]) => (
              <a key={href} href={href} onClick={() => setOpen(false)} className="focus-ring flex items-center justify-between border-b border-[hsl(var(--border)/0.7)] py-3 text-sm font-bold text-[hsl(var(--primary))]" data-testid={`link-mobile-${label.toLowerCase().replaceAll(' ', '-')}`}>
                {label}<IconSquare icon={ArrowRight} size="sm" />
              </a>
            ))}
            <a href="#contact" onClick={() => setOpen(false)} className="focus-ring mt-4 inline-flex w-fit items-center gap-2 rounded-full bg-[hsl(var(--secondary))] px-5 py-3 text-xs font-bold uppercase tracking-[0.12em] text-[hsl(var(--secondary-foreground))]" data-testid="link-mobile-enquire">
              Enquire now <IconSquare icon={ArrowRight} size="sm" />
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}

function SocialLinks({ location }: { location: 'header' | 'footer' }) {
  return (
    <div className="flex items-center gap-2" aria-label="Social media">
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="MIDG Academy on WhatsApp"
        title="WhatsApp"
        className="focus-ring inline-flex rounded-xl transition-transform hover:-translate-y-0.5"
        data-testid={`link-${location}-whatsapp`}
      >
        <IconSquare icon={MessageCircle} size="sm" />
      </a>
      <a
        href={INSTAGRAM_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="MIDG Academy on Instagram"
        title="Instagram"
        className="focus-ring inline-flex rounded-xl transition-transform hover:-translate-y-0.5"
        data-testid={`link-${location}-instagram`}
      >
        <IconSquare icon={Instagram} size="sm" />
      </a>
      <a
        href={YOUTUBE_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="MIDG Academy on YouTube"
        title="YouTube"
        className="focus-ring inline-flex rounded-xl transition-transform hover:-translate-y-0.5"
        data-testid={`link-${location}-youtube`}
      >
        <IconSquare icon={Youtube} size="sm" />
      </a>
      <a
        href={FACEBOOK_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="MIDG Academy on Facebook"
        title="Facebook"
        className="focus-ring inline-flex rounded-xl transition-transform hover:-translate-y-0.5"
        data-testid={`link-${location}-facebook`}
      >
        <IconSquare icon={Facebook} size="sm" />
      </a>
    </div>
  );
}

function SectionIntro({ eyebrow, title, copy, light = false }: { eyebrow: string; title: string; copy: string; light?: boolean }) {
  return (
    <div className={`max-w-2xl ${light ? 'text-[hsl(var(--primary-foreground))]' : ''}`} data-reveal>
      <div className={`mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.25em] ${light ? 'text-[hsl(var(--secondary))]' : 'text-[hsl(var(--secondary-foreground))]'}`}>
        <span className="section-line h-px w-10 bg-[hsl(var(--secondary))]" /> {eyebrow}
      </div>
      <h2 className="font-serif text-3xl leading-[1.16] sm:text-4xl lg:text-[3.1rem]" data-testid={`heading-${eyebrow.toLowerCase().replaceAll(' ', '-')}`}>{title}</h2>
      <p className={`mt-5 max-w-xl text-base leading-7 ${light ? 'text-[hsl(var(--primary-foreground)/0.73)]' : 'text-[hsl(var(--muted-foreground))]'}`}>{copy}</p>
    </div>
  );
}

function Home() {
  const [form, setForm] = useState({ name: '', interest: '', message: '' });

  useEffect(() => {
    document.title = 'MIDG Academy of Education Services | Learn • Grow • Succeed';
    const description = 'MIDG Academy of Education Services offers educational support, academic tutoring, professional training and skill development. Learn • Grow • Succeed.';
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
  }, []);

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const targets = document.querySelectorAll<HTMLElement>('[data-reveal], [data-reveal-stagger]');
    if (reduceMotion || !('IntersectionObserver' in window) || targets.length === 0) return;

    document.documentElement.classList.add('motion-ready');
    const observer = new IntersectionObserver((entries, currentObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          currentObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    targets.forEach((target) => observer.observe(target));
    return () => {
      observer.disconnect();
      document.documentElement.classList.remove('motion-ready');
    };
  }, []);

  const submitEnquiry = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const message = `Hello MIDG Academy, my name is ${form.name || 'a prospective learner'}. I am interested in ${form.interest || 'learning more about your services'}. ${form.message}`.trim();
    window.open(`${WHATSAPP_URL}?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="grain min-h-[100dvh] overflow-hidden">
      <Header />
      <main>
        <section id="home" className="relative scroll-mt-24 overflow-hidden bg-[hsl(var(--primary))] pt-[76px] text-[hsl(var(--primary-foreground))]">
          <div className="hero-orbit absolute -right-32 top-24 h-72 w-72 rounded-full border border-[hsl(var(--secondary)/0.24)] sm:h-[32rem] sm:w-[32rem]" />
          <div className="hero-orbit hero-orbit-delay absolute -right-20 top-44 h-56 w-56 rounded-full border border-[hsl(var(--secondary)/0.16)] sm:h-[24rem] sm:w-[24rem]" />
          <div className="mx-auto grid min-h-[650px] max-w-[1320px] items-center gap-12 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-[1fr_0.8fr] lg:px-12 lg:py-24">
            <div className="relative z-10">
              <div className="animate-reveal mb-8 inline-flex items-center gap-2 border border-[hsl(var(--secondary)/0.4)] px-3 py-2 text-[10px] font-bold uppercase tracking-[0.23em] text-[hsl(var(--secondary))]">
                <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--secondary))]" /> Education with direction
              </div>
              <h1 className="animate-reveal animate-reveal-delay-1 max-w-3xl font-serif text-5xl leading-[1.04] sm:text-6xl lg:text-[5.5rem]" data-testid="heading-hero">
                Learn with purpose.<br /><span className="text-[hsl(var(--secondary))]">Move forward.</span>
              </h1>
              <p className="animate-reveal animate-reveal-delay-2 mt-7 max-w-xl text-lg leading-8 text-[hsl(var(--primary-foreground)/0.76)]">
                MIDG Academy of Education Services brings together educational support, professional training and skills for the next chapter of your journey.
              </p>
              <div className="animate-reveal animate-reveal-delay-3 mt-9 flex flex-wrap items-center gap-4">
                <a href="#contact" className="focus-ring inline-flex items-center gap-3 rounded-full bg-[hsl(var(--secondary))] px-6 py-4 text-sm font-bold text-[hsl(var(--secondary-foreground))] transition-transform hover:-translate-y-1" data-testid="link-hero-enquire">
                  Start a conversation <IconSquare icon={ArrowRight} size="sm" />
                </a>
                <a href="#training" className="focus-ring inline-flex items-center gap-2 px-3 py-4 text-sm font-bold text-[hsl(var(--primary-foreground)/0.9)]" data-testid="link-hero-explore">
                  Explore learning <IconSquare icon={Compass} size="sm" />
                </a>
              </div>
              <div className="mt-14 flex items-center gap-5 text-xs text-[hsl(var(--primary-foreground)/0.6)]">
                <span className="font-serif text-lg italic text-[hsl(var(--secondary))]">Learn <span className="not-italic">•</span> Grow <span className="not-italic">•</span> Succeed</span>
              </div>
            </div>
            <div className="relative z-10 flex justify-center lg:justify-end">
              <div className="float-mark relative aspect-square w-[min(76vw,420px)] rounded-full border border-[hsl(var(--secondary)/0.55)] p-3 sm:p-5">
                  <div className="mark-arrive flex h-full w-full items-center justify-center rounded-full bg-[hsl(var(--background))] p-5 shadow-2xl sm:p-8">
                  <img src="/midg-academy-logo-round.png" alt="MIDG Academy seal" className="h-full w-full object-contain" data-testid="img-hero-logo" />
                </div>
                <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap bg-[hsl(var(--secondary))] px-4 py-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[hsl(var(--secondary-foreground))]">Grounded in learning</span>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-10 bg-[hsl(var(--background))]" style={{ clipPath: 'polygon(0 100%, 0 0, 17% 65%, 34% 16%, 52% 70%, 71% 30%, 87% 77%, 100% 20%, 100% 100%)' }} />
        </section>

        <section id="about" className="scroll-mt-24 bg-[hsl(var(--background))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto grid max-w-[1320px] gap-16 lg:grid-cols-[0.76fr_1.24fr] lg:items-center">
            <div className="relative" data-reveal>
              <div className="absolute -left-5 -top-5 h-28 w-28 border-l border-t border-[hsl(var(--secondary))]" />
              <div className="relative bg-[hsl(var(--accent))] p-8 sm:p-12">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--muted-foreground))]">MIDG / 01</p>
                <p className="mt-12 font-serif text-4xl leading-tight text-[hsl(var(--primary))] sm:text-5xl">A clearer path<br /><em className="text-[hsl(var(--secondary-foreground))]">starts here.</em></p>
                <div className="mt-14 h-px w-full bg-[hsl(var(--secondary)/0.45)]" />
                <p className="mt-4 text-xs leading-6 text-[hsl(var(--muted-foreground))]">Learning support for where you are, and the direction you want to take.</p>
              </div>
              <div className="absolute -bottom-4 -right-4 flex h-20 w-20 items-center justify-center rounded-full bg-[hsl(var(--secondary))] text-center text-[9px] font-bold uppercase leading-4 tracking-wider text-[hsl(var(--secondary-foreground))]">Learn<br />Grow<br />Succeed</div>
            </div>
            <div data-reveal>
              <SectionIntro eyebrow="About us" title="Education that respects the whole journey." copy="MIDG Academy of Education Services is an Indian education and professional-training provider focused on meaningful support — from academic foundations to workplace readiness." />
              <div className="mt-10 grid gap-6 border-t border-[hsl(var(--border))] pt-8 sm:grid-cols-2">
                <div className="flex gap-4">
                  <IconSquare icon={Users} />
                  <div><h3 className="font-bold text-[hsl(var(--primary))]">Learner-first support</h3><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Guidance shaped around real goals, context and confidence.</p></div>
                </div>
                <div className="flex gap-4">
                  <IconSquare icon={HeartHandshake} />
                  <div><h3 className="font-bold text-[hsl(var(--primary))]">Practical perspective</h3><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Learning designed to connect with study, work and life.</p></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="training" className="scroll-mt-24 bg-[hsl(var(--accent))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1320px]">
            <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
              <SectionIntro eyebrow="Courses & training" title="Learning built around your next step." copy="Explore the areas MIDG Academy supports. Speak with the team to understand the right fit for your needs." />
              <a href="#contact" className="focus-ring inline-flex items-center gap-2 text-sm font-bold text-[hsl(var(--primary))] underline decoration-[hsl(var(--secondary))] decoration-2 underline-offset-8" data-testid="link-training-enquire">Discuss your goals <IconSquare icon={Compass} size="sm" /></a>
            </div>
            <div className="mt-14 grid gap-4 lg:grid-cols-3" data-reveal-stagger>
              {trainingAreas.map(({ number, title, copy, icon: Icon }) => (
                <article key={number} className="group border border-[hsl(var(--border))] bg-[hsl(var(--background))] p-7 transition-transform duration-300 hover:-translate-y-2 sm:p-9" data-testid={`card-training-${number}`}>
                  <div className="flex items-start justify-between"><span className="font-mono text-xs text-[hsl(var(--secondary-foreground))]">{number}</span><IconSquare icon={Icon} size="lg" /></div>
                  <h3 className="mt-16 font-serif text-2xl text-[hsl(var(--primary))]">{title}</h3>
                  <p className="mt-4 text-sm leading-6 text-[hsl(var(--muted-foreground))]">{copy}</p>
                  <a href="#contact" className="focus-ring mt-8 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.15em] text-[hsl(var(--primary))]" data-testid={`link-training-${number}`}>Learn more <IconSquare icon={ArrowRight} size="sm" className="transition-transform group-hover:translate-x-1" /></a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="services" className="scroll-mt-24 bg-[hsl(var(--background))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto grid max-w-[1320px] gap-14 lg:grid-cols-[0.8fr_1.2fr]">
            <SectionIntro eyebrow="Services" title="Support that meets you where you are." copy="From individual learning to organisational development, our services cover the practical work of building capability." />
            <div className="grid grid-cols-1 border-t border-[hsl(var(--border))] sm:grid-cols-2" data-reveal>
              {services.map((service, index) => (
                <a key={service} href="#contact" className="focus-ring group flex items-center gap-4 border-b border-[hsl(var(--border))] py-4 text-sm font-medium text-[hsl(var(--primary))] transition-colors hover:text-[hsl(var(--secondary-foreground))]" data-testid={`link-service-${index}`}>
                  <IconSquare icon={serviceIcons[service] ?? Compass} size="sm" /><span>{service}</span><IconSquare icon={ArrowRight} size="sm" className="ml-auto opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100" />
                </a>
              ))}
            </div>
          </div>
          <article className="mx-auto mt-14 grid max-w-[1320px] border border-[hsl(var(--border))] bg-[hsl(var(--accent))] md:grid-cols-[1fr_1fr]" data-testid="card-honorary-doctorate-consultancy" data-reveal>
            <div className="p-7 sm:p-10">
              <p className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-[hsl(var(--secondary-foreground))]">Specialist consultancy</p>
              <h3 className="mt-4 font-serif text-2xl leading-snug text-[hsl(var(--primary))] sm:text-3xl">Honorary Doctorate Guidance &amp; Consultancy</h3>
              <p className="mt-5 text-sm leading-7 text-[hsl(var(--muted-foreground))]" data-testid="text-honorary-doctorate-description">
                Guidance and consultancy for individuals interested in understanding honorary doctorate opportunities, eligibility criteria, nomination processes, institutional requirements, documentation, and verification of university recognition and accreditation.
              </p>
              <a href="#contact" className="focus-ring mt-7 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[hsl(var(--primary))]" data-testid="link-honorary-doctorate-enquiry">
                Enquire about this service <IconSquare icon={ArrowRight} size="sm" />
              </a>
            </div>
            <div className="border-t border-[hsl(var(--border))] p-7 md:border-l md:border-t-0 sm:p-10">
              <h4 className="font-serif text-xl text-[hsl(var(--primary))]">Guidance can include</h4>
              <ul className="mt-5 grid gap-3 sm:grid-cols-2">
                {honoraryDoctorateSupport.map((item, index) => (
                  <li key={item} className="flex items-start gap-3 text-sm leading-6 text-[hsl(var(--muted-foreground))]" data-testid={`text-honorary-doctorate-support-${index}`}>
                    <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[hsl(var(--secondary-foreground))]" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </article>
        </section>

        <ProspectusSection />

        <section id="certificates" className="scroll-mt-24 bg-[hsl(var(--primary))] px-5 py-24 text-[hsl(var(--primary-foreground))] sm:px-8 lg:px-12 lg:py-28">
          <div className="mx-auto grid max-w-[1320px] gap-12 lg:grid-cols-[1fr_1fr] lg:items-center">
            <SectionIntro light eyebrow="Certificates" title="Keep the record clear." copy="Certificate-related questions are best discussed with the MIDG Academy team in the context of your chosen learning support or training engagement. Please enquire for accurate, current details." />
            <div className="border border-[hsl(var(--secondary)/0.42)] bg-[hsl(var(--primary)/0.45)] p-7 sm:p-10" data-reveal>
              <div className="flex items-start gap-5">
                <IconSquare icon={FileText} size="lg" />
                <div><p className="font-mono text-[10px] uppercase tracking-[0.18em] text-[hsl(var(--secondary))]">A factual conversation</p><h3 className="mt-3 font-serif text-2xl">Ask before you enrol.</h3><p className="mt-3 text-sm leading-6 text-[hsl(var(--primary-foreground)/0.68)]">We keep information about certificates specific to the service and learning context. Contact us for details.</p></div>
              </div>
              <a href="#contact" className="focus-ring mt-8 inline-flex items-center gap-2 rounded-full border border-[hsl(var(--secondary))] px-5 py-3 text-xs font-bold uppercase tracking-[0.12em] text-[hsl(var(--secondary))]" data-testid="link-certificate-enquiry">Make an enquiry <IconSquare icon={ArrowRight} size="sm" /></a>
            </div>
          </div>
        </section>

        <section id="accreditations" className="scroll-mt-24 bg-[hsl(var(--background))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1320px]">
            <SectionIntro eyebrow="Accreditations & registration" title="The details, plainly stated." copy="Reference information supplied by MIDG Academy of Education Services." />
            <div className="mt-12 grid gap-4 md:grid-cols-3" data-reveal-stagger>
              <div className="border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-7" data-testid="card-iso"><IconSquare icon={ShieldCheck} /><p className="mt-12 font-mono text-xs uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">Certification</p><p className="mt-2 font-serif text-2xl text-[hsl(var(--primary))]">ISO 27001:2022</p>{/* TODO: add certificate no., issuing body and scope */}</div>
              <div className="border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-7" data-testid="card-udyam"><IconSquare icon={ClipboardCheck} /><p className="mt-12 font-mono text-xs uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">Udyam Registration No.</p><p className="mt-2 break-all font-mono text-base font-bold text-[hsl(var(--primary))]">UDYAM-TN-02-0510507</p></div>
              <div className="border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-7" data-testid="card-business"><IconSquare icon={Building2} /><p className="mt-12 font-mono text-xs uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">Business details</p><p className="mt-2 text-sm leading-6 text-[hsl(var(--primary))]">Micro Enterprise<br />Major Activity: Services</p></div>
            </div>
            <div className="mt-5 border-l-2 border-[hsl(var(--secondary))] bg-[hsl(var(--accent))] px-6 py-5 text-sm leading-7 text-[hsl(var(--muted-foreground))]"><span className="font-bold text-[hsl(var(--primary))]">Registered activities:</span> Educational Support Services, Advertising, Publishing Activities, Academic Tutoring Services.</div>
            <div className="mt-8 overflow-x-auto rounded-md border border-[hsl(var(--border))] bg-white" role="region" aria-label="Accreditations and registration marks" tabIndex={0} data-testid="image-accreditation-strip" data-reveal>
              <img src="/accreditation-registration-strip.png" alt="Marks supplied by MIDG Academy: ISO, Startup India, Bhaskar (MeitY) and other registration badges" className="block h-auto w-[900px] max-w-none md:w-full" loading="lazy" />
            </div>
          </div>
        </section>

        <section id="partnerships" className="scroll-mt-24 bg-[hsl(var(--accent))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1320px]">
            <SectionIntro eyebrow="MIDG Academy" title="University collaborations & partnerships." copy="Institutions listed by MIDG Academy under university collaboration or partnership." />
            <div className="mt-12 grid gap-4 sm:grid-cols-2 xl:grid-cols-4" data-testid="grid-university-partners" data-reveal-stagger>
              {universityPartners.map(({ name, logo }) => (
                <article key={name} className="border border-[hsl(var(--border))] bg-[hsl(var(--background))] p-5 sm:p-6" data-testid={`card-partner-${name.toLowerCase().replaceAll(/[^a-z0-9]+/g, '-')}`}>
                  <div className="flex h-32 items-center justify-center bg-white px-3 py-2">
                    <img src={logo} alt={`${name} logo`} className="max-h-full max-w-full object-contain" />
                  </div>
                  <h3 className="mt-5 border-t border-[hsl(var(--border))] pt-4 text-center text-sm font-bold leading-6 text-[hsl(var(--primary))]">{name}</h3>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="founders" className="scroll-mt-24 bg-[hsl(var(--accent))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1320px]">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><SectionIntro eyebrow="Leadership team" title="Our leadership team." copy="Meet the leaders of MIDG Academy of Education Services." /><span className="font-mono text-xs uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">MIDG / PEOPLE</span></div>
            <div className="mt-14 grid gap-px bg-[hsl(var(--border))] md:grid-cols-3" data-reveal-stagger>
              {[
                ['Mrs. Indra M', '', 'Co-Founder & Managing Director', '9003140003', 'IM'],
                ['Dr. S. Gayathri', '', 'Co-Founder & Academic Head', '8825712128', 'SG'],
                ['Dr. Durga M', 'DM (Hons.)', 'Founder & Chairperson', '8754064171', 'DM'],
              ].map(([name, credential, role, phone, initials], index) => (
                <article key={name} className="bg-[hsl(var(--background))] p-7 sm:p-9" data-testid={`card-founder-${index}`}>
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[hsl(var(--primary))] font-serif text-xl text-[hsl(var(--secondary))]">{initials}</div>
                  <h3 className="mt-9 font-serif text-2xl text-[hsl(var(--primary))]">{name}</h3>
                  {credential && <p className="mt-1 text-sm font-bold text-[hsl(var(--secondary-foreground))]">{credential}</p>}
                  <p className="mt-3 min-h-10 text-sm leading-5 text-[hsl(var(--muted-foreground))]">{role}</p>
                  <a href={`tel:${phone}`} className="focus-ring mt-8 inline-flex items-center gap-2 text-xs font-bold tracking-wide text-[hsl(var(--primary))]" data-testid={`link-founder-phone-${index}`}><IconSquare icon={Phone} size="sm" /> {phone}</a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="scroll-mt-24 bg-[hsl(var(--background))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto grid max-w-[1320px] gap-14 lg:grid-cols-[0.85fr_1.15fr]">
            <div data-reveal>
              <SectionIntro eyebrow="Contact" title="Your next chapter can start with a question." copy="Tell us a little about what you are looking for. Your enquiry will open WhatsApp with a prefilled message so you can continue the conversation directly." />
              <div className="mt-10 space-y-4">
                <a href="mailto:midgacademy@gmail.com" className="focus-ring flex items-center gap-4 text-sm font-medium text-[hsl(var(--primary))]" data-testid="link-contact-email"><IconSquare icon={Mail} />midgacademy@gmail.com</a>
                <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" className="focus-ring group flex items-center gap-4 text-sm font-medium text-[hsl(var(--primary))]" data-testid="link-contact-whatsapp"><IconSquare icon={MessageCircle} />WhatsApp · 8754064171</a>
                <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="focus-ring group flex items-center gap-4 text-sm font-medium text-[hsl(var(--primary))]" data-testid="link-contact-instagram"><IconSquare icon={Instagram} />@midg.academy.in</a>
              </div>
              <div className="mt-9">
                <h3 className="font-serif text-xl text-[hsl(var(--primary))]">Find us online</h3>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {publicProfileLinks.map(({ label, detail, href, icon: Icon }) => (
                    <a key={label} href={href} target="_blank" rel="noopener noreferrer" className="focus-ring group flex min-h-[76px] items-center gap-3 border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3 transition-colors hover:border-[hsl(var(--secondary))]" data-testid={`link-contact-${label.toLowerCase().replaceAll(' ', '-')}`}>
                      <IconSquare icon={Icon} />
                      <span className="min-w-0"><span className="block text-xs font-bold text-[hsl(var(--primary))]">{label}</span><span className="mt-1 block truncate text-[10px] text-[hsl(var(--muted-foreground))]">{detail}</span></span>
                      <IconSquare icon={ArrowRight} size="sm" className="ml-auto transition-transform group-hover:translate-x-0.5" />
                    </a>
                  ))}
                </div>
              </div>
            </div>
            <form onSubmit={submitEnquiry} className="border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 shadow-[0_20px_60px_rgba(20,36,65,0.08)] sm:p-10" data-testid="form-enquiry" data-reveal>
              <div className="mb-8 flex items-center justify-between border-b border-[hsl(var(--border))] pb-5"><h3 className="font-serif text-2xl text-[hsl(var(--primary))]">Make an enquiry</h3><IconSquare icon={Send} /></div>
              <div className="grid gap-6">
                <label className="grid gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">Your name<input required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} className="focus-ring rounded-none border-0 border-b border-[hsl(var(--border))] bg-transparent px-0 py-3 text-base font-medium normal-case tracking-normal text-[hsl(var(--primary))] outline-none placeholder:text-[hsl(var(--muted-foreground)/0.6)]" placeholder="How should we address you?" data-testid="input-enquiry-name" /></label>
                <label className="grid gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">I am interested in<input value={form.interest} onChange={(event) => setForm({ ...form, interest: event.target.value })} className="focus-ring rounded-none border-0 border-b border-[hsl(var(--border))] bg-transparent px-0 py-3 text-base font-medium normal-case tracking-normal text-[hsl(var(--primary))] outline-none placeholder:text-[hsl(var(--muted-foreground)/0.6)]" placeholder="A service or learning area" data-testid="input-enquiry-interest" /></label>
                <label className="grid gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">A little more<textarea rows={3} value={form.message} onChange={(event) => setForm({ ...form, message: event.target.value })} className="focus-ring rounded-none border-0 border-b border-[hsl(var(--border))] bg-transparent px-0 py-3 text-base font-medium normal-case tracking-normal text-[hsl(var(--primary))] outline-none placeholder:text-[hsl(var(--muted-foreground)/0.6)]" placeholder="Share a question or goal" data-testid="input-enquiry-message" /></label>
              </div>
              <button type="submit" className="focus-ring mt-10 inline-flex w-full items-center justify-center gap-3 rounded-full bg-[hsl(var(--primary))] px-6 py-4 text-sm font-bold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5" data-testid="button-submit-enquiry">Continue on WhatsApp <IconSquare icon={ArrowRight} size="sm" /></button>
              <p className="mt-4 text-center text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">No backend form submission — this opens a prefilled WhatsApp message.</p>
            </form>
          </div>
        </section>
      </main>
      <footer className="bg-[hsl(var(--primary))] px-5 py-10 text-[hsl(var(--primary-foreground))] sm:px-8 lg:px-12">
        <div className="mx-auto flex max-w-[1320px] flex-col gap-8 md:flex-row md:items-center md:justify-between">
          <a href="#home" className="focus-ring flex items-center gap-3" data-testid="link-footer-logo"><img src="/midg-academy-logo-round.png" alt="MIDG Academy of Education Services" className="h-16 w-16 rounded-full bg-[hsl(var(--background))] object-contain" /><span className="font-serif text-lg">MIDG Academy</span></a>
          <div className="flex flex-wrap gap-x-6 gap-y-3 text-[11px] font-bold uppercase tracking-[0.12em] text-[hsl(var(--primary-foreground)/0.68)]">{navItems.slice(0, 4).map(([label, href]) => <a key={href} href={href} className="focus-ring hover:text-[hsl(var(--secondary))]" data-testid={`link-footer-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</a>)}</div>
          <SocialLinks location="footer" />
          <p className="font-mono text-[10px] text-[hsl(var(--primary-foreground)/0.52)]">© {new Date().getFullYear()} MIDG Academy of Education Services</p>
        </div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;