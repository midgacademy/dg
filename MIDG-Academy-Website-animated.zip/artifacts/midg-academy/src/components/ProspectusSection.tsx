import { ArrowDownToLine, ArrowUpRight, Check, FileText, IndianRupee } from 'lucide-react';

const prospectusUrl = '/midg-academy-prospectus.pdf';

const guideTopics = [
  {
    title: 'Admissions guidance',
    detail: '10th & 12th · UG & PG · Medical · B.Ed',
  },
  {
    title: 'Courses & learning',
    detail: 'UG & PG · Diploma · Certificate · Online',
  },
  {
    title: 'Training programmes',
    detail: 'Professional · Corporate · Colleges · Schools',
  },
  {
    title: 'Internships & projects',
    detail: 'Internship opportunities and college projects',
  },
  {
    title: 'B.Ed admissions',
    detail: 'Information and guidance for prospective applicants',
  },
  {
    title: 'Fees & programme details',
    detail: 'Fees vary by institution and programme',
  },
];

function ProspectusSection() {
  return (
    <section
      id="prospectus"
      aria-labelledby="prospectus-heading"
      className="relative isolate overflow-hidden bg-[hsl(var(--background))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32"
      data-testid="section-prospectus"
    >
      <div aria-hidden="true" className="pointer-events-none absolute -left-32 top-16 h-80 w-80 rounded-full border border-[hsl(var(--secondary)/0.24)]" />
      <div aria-hidden="true" className="pointer-events-none absolute -left-20 top-28 h-56 w-56 rounded-full border border-[hsl(var(--secondary)/0.18)]" />

      <div className="relative mx-auto grid max-w-[1320px] items-center gap-16 lg:grid-cols-[0.9fr_1.1fr] lg:gap-24">
        <div className="order-2 lg:order-1" data-reveal>
          <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.25em] text-[hsl(var(--secondary-foreground))]">
            <span aria-hidden="true" className="h-px w-10 bg-[hsl(var(--secondary))]" />
            A guide to your next step
          </div>
          <h2 id="prospectus-heading" className="max-w-xl font-serif text-4xl leading-[1.13] text-[hsl(var(--primary))] sm:text-5xl lg:text-[3.5rem]" data-testid="heading-prospectus">
            Our
            <span className="block italic text-[hsl(var(--secondary-foreground))]">Prospectus</span>
          </h2>
          <p className="mt-6 max-w-xl text-base leading-8 text-[hsl(var(--muted-foreground))]" data-testid="text-prospectus-description">
            Explore admissions, courses, training, internships and programme fees in one guide. Find the details you need to plan your next step with MIDG Academy.
          </p>

          <ul className="mt-9 grid gap-x-8 border-y border-[hsl(var(--border))] sm:grid-cols-2" data-testid="list-prospectus-topics">
            {guideTopics.map(({ title, detail }, index) => (
              <li key={title} className="flex gap-3.5 border-b border-[hsl(var(--border)/0.72)] py-4 last:border-b-0 sm:[&:nth-last-child(2)]:border-b-0" data-testid={`item-prospectus-topic-${index + 1}`}>
                <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--primary))] text-[hsl(var(--secondary))]" aria-hidden="true">
                  <Check className="h-4 w-4" strokeWidth={1.9} />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-[hsl(var(--primary))]" data-testid={`text-prospectus-topic-${index + 1}`}>{title}</h3>
                  <p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{detail}</p>
                </div>
              </li>
            ))}
          </ul>

          <p className="mt-4 flex items-start gap-2 text-xs leading-5 text-[hsl(var(--muted-foreground))]" data-testid="text-prospectus-fees-note">
            <span aria-hidden="true" className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--primary))] text-[hsl(var(--secondary))]"><IndianRupee className="h-3.5 w-3.5" /></span>
            Fees are programme- and institution-specific; confirm current details directly with the team.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href={prospectusUrl}
              download
              aria-label="Download the MIDG Academy prospectus PDF"
              className="focus-ring group inline-flex min-h-12 items-center justify-center gap-3 rounded-full bg-[hsl(var(--primary))] px-6 py-3 text-sm font-bold text-[hsl(var(--primary-foreground))] shadow-[0_12px_30px_hsl(var(--primary)/0.16)] transition-[transform,box-shadow] duration-300 hover:-translate-y-1 hover:shadow-[0_18px_36px_hsl(var(--primary)/0.22)]"
              data-testid="link-prospectus-download"
            >
              <span aria-hidden="true" className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--primary))] text-[hsl(var(--secondary))]"><ArrowDownToLine className="h-4 w-4" /></span>
              Download PDF
            </a>
            <a
              href={prospectusUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="View the MIDG Academy prospectus PDF in a new tab"
              className="focus-ring group inline-flex min-h-12 items-center justify-center gap-3 rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-6 py-3 text-sm font-bold text-[hsl(var(--primary))] transition-[transform,border-color] duration-300 hover:-translate-y-1 hover:border-[hsl(var(--secondary))]"
              data-testid="link-prospectus-view"
            >
              <span aria-hidden="true" className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--primary))] text-[hsl(var(--secondary))]"><FileText className="h-4 w-4" /></span>
              View Online
              <span aria-hidden="true" className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--primary))] text-[hsl(var(--secondary))] transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"><ArrowUpRight className="h-3.5 w-3.5" /></span>
            </a>
          </div>
          <p className="mt-4 text-[11px] tracking-wide text-[hsl(var(--muted-foreground))]" data-testid="text-prospectus-format">
            Official guide <span aria-hidden="true">·</span> PDF <span aria-hidden="true">·</span> 15 pages
          </p>
        </div>

        <div className="order-1 flex min-h-[390px] items-center justify-center py-5 sm:min-h-[500px] lg:order-2 lg:justify-end" data-reveal>
          <div className="relative w-[min(80vw,340px)] [perspective:1200px] sm:w-[min(64vw,390px)]" data-testid="artwork-prospectus-booklet">
            <div aria-hidden="true" className="absolute -inset-5 translate-x-5 translate-y-5 rotate-[5deg] border border-[hsl(var(--secondary)/0.34)] bg-[hsl(var(--accent))] shadow-[0_30px_60px_hsl(var(--primary)/0.10)]" />
            <div className="relative rotate-[-4deg] rounded-[3px] border-[5px] border-[hsl(var(--secondary))] bg-[hsl(var(--primary))] p-1 shadow-[0_35px_70px_hsl(var(--primary)/0.24)] transition-transform duration-700 ease-out hover:rotate-[-1deg] hover:scale-[1.025] motion-reduce:transform-none motion-reduce:transition-none">
              <div className="relative aspect-[724/1024] overflow-hidden border border-[hsl(var(--secondary)/0.65)] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]" data-testid="artwork-prospectus-cover">
                <div aria-hidden="true" className="absolute inset-3 border border-[hsl(var(--secondary)/0.38)]" />
                <div className="relative flex h-full flex-col items-center px-6 py-7 text-center sm:px-8 sm:py-9">
                  <p className="max-w-[220px] text-[9px] font-bold uppercase leading-4 tracking-[0.2em] text-[hsl(var(--secondary))]">
                    MIDG Academy of Education Services
                  </p>
                  <div className="my-6 flex h-20 w-20 shrink-0 items-center justify-center rounded-full border-2 border-[hsl(var(--secondary))] bg-[hsl(var(--background))] p-1.5 shadow-[0_0_28px_hsl(var(--secondary)/0.22)]">
                    <img src="/midg-academy-logo-round.png" alt="" className="h-full w-full rounded-full object-contain" aria-hidden="true" />
                  </div>
                  <p className="font-mono text-[9px] font-bold uppercase tracking-[0.28em] text-[hsl(var(--secondary))]">Prospectus</p>
                  <h3 className="mt-4 max-w-[250px] font-serif text-[2rem] leading-[1.04] sm:text-[2.35rem]">
                    Empowering
                    <span className="mt-1 block text-[hsl(var(--secondary))]">your educational journey</span>
                  </h3>
                  <p className="mt-4 max-w-[245px] text-[10px] leading-5 text-[hsl(var(--primary-foreground)/0.74)]">
                    Personalised guidance, academic support, career development and practical training.
                  </p>
                  <div className="mt-auto w-full border-t border-[hsl(var(--secondary)/0.42)] pt-4">
                    <p className="text-[9px] font-semibold leading-5 tracking-wide text-[hsl(var(--primary-foreground)/0.88)]">
                      UG &amp; PG <span className="text-[hsl(var(--secondary))]">·</span> B.Ed <span className="text-[hsl(var(--secondary))]">·</span> Training <span className="text-[hsl(var(--secondary))]">·</span> Internships <span className="text-[hsl(var(--secondary))]">·</span> Placement
                    </p>
                    <p className="mt-2 font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-[hsl(var(--secondary))]">
                      Knowledge · Opportunity · Impact
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-4 -left-5 flex items-center gap-3 border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--background))] px-3 py-2.5 shadow-[0_14px_35px_hsl(var(--primary)/0.12)] sm:-left-12 sm:px-4">
              <img src="/midg-academy-logo-round.png" alt="" className="h-10 w-10 rounded-full object-contain" aria-hidden="true" />
              <div>
                <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">MIDG Academy</p>
                <p className="mt-0.5 font-serif text-sm text-[hsl(var(--primary))]">Learn · Grow · Succeed</p>
              </div>
            </div>
            <div aria-hidden="true" className="absolute -right-7 top-5 hidden h-20 w-20 items-center justify-center rounded-full border border-[hsl(var(--secondary)/0.65)] bg-[hsl(var(--background))] text-center font-mono text-[8px] uppercase leading-4 tracking-[0.16em] text-[hsl(var(--primary))] sm:flex">
              Education<br />&amp; direction
              <span className="absolute inset-1 rounded-full border border-[hsl(var(--secondary)/0.28)]" />
            </div>
          </div>
        </div>
      </div>

      <div aria-hidden="true" className="pointer-events-none absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[hsl(var(--secondary)/0.65)] to-transparent" />
    </section>
  );
}

export default ProspectusSection;
