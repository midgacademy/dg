---
name: Evidence-based claims
description: Guardrails for public claims about MIDG Academy affiliations, approvals and recognition.
---

Do not invent affiliations, approvals, rankings, awards or accreditation claims that are not provided. Only publish these claims when the available source supports the exact wording.

**Why:** the user asked to avoid unsupported claims.

**How to apply:** check supplied documents before adding partner, membership, nomination, accreditation or recognition language to the MIDG Academy website; when the relationship is unclear, leave it out and ask for clarification.