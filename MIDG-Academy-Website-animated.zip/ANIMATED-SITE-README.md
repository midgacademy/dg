# Animated MIDG Academy website

The live page is now `artifacts/midg-academy/index.html`: a single static page with all styles and animation inside it. It uses the images in `artifacts/midg-academy/public/`.

- The previous React page is untouched in `artifacts/midg-academy/src/` and `artifacts/midg-academy/index.react-original.html`. To go back, copy that file over `index.html`.
- `deploy-ready/` has the finished site as plain files. Upload its contents to any hosting (Netlify, GitHub Pages, cPanel) and it works.
- Still to do: replace `REPLACE-WITH-YOUR-DOMAIN` in `index.html`, `public/robots.txt` and `public/sitemap.xml`.
